function airplanesAdm(){
    document.location.replace("indexAirplanesAdm.html");
}