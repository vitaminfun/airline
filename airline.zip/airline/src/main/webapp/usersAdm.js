function usersAdm(){
    document.location.replace("indexUsersAdm.html");
}