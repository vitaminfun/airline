flightAjax('POST','sendFlight', null ,true);

