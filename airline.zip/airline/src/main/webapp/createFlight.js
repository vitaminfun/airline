function createFlight() {
    // let inpAirplane = document.getElementById("idAirplane");
    // let inpFrom = document.getElementById("from");
    // let inpTo = document.getElementById("to");
    // let inpDate = document.getElementById("date");
    //
    // let idAirplane = inpAirplane.value;
    // let from = inpFrom.value;
    // let to = inpTo.value;
    // let date = inpDate.value;
    //
    // let flight={
    //     idAirplane: idAirplane,
    //     from: from,
    //     to: to,
    //     date: date,
    // };
    //
    // let json=JSON.stringify(flight);
    // alert(json)
    //
    // createFlightAjax('POST','createFlight', json ,true);

}