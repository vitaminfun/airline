function addUser() {
    document.location.replace("addUser.html")
}