function flightsAdm(){
    document.location.replace("indexFlightsAdm.html");
}