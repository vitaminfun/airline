function addAirplane() {
    document.location.replace("addAirplane.html")
}