function addFlight() {
    document.location.replace("addFlight.html")
}